"use client";

import type {
  AkanukeAnalysis,
} from "../../lib/openai/schemas";
import Link from "next/link";
import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import AppHeader from "../components/AppHeader";
import AppShell from "../components/AppShell";
import { trackEvent } from "../../lib/analytics";

const DIAGNOSIS_ID_STORAGE_KEY =
  "akanukeDiagnosisId";

type PlanTask = {
  id: string;
  priority: number;
  category: string;
  title: string;
  reason: string;
  effect: string;
  howTo: string;
  href?: string;
  hrefLabel?: string;
};

const planTasks: PlanTask[] = [
  {
    id: "hair-salon",
    priority: 1,
    category: "髪型",
    title: "美容室で髪型を整える",
    reason:
      "髪型は顔全体の印象を最も大きく変えやすい項目です。",
    effect:
      "前髪とサイドが整い、輪郭がすっきり見えます。",
    howTo:
      "額が少し見える軽めの前髪と、サイドを抑えた爽やかなスタイルを相談しましょう。",
    href: "/products?category=hairStyling",
    hrefLabel:
      "スタイリング商品を見る",
  },
  {
    id: "eyebrow",
    priority: 2,
    category: "眉毛",
    title: "眉毛の輪郭を整える",
    reason:
      "眉毛を整えると目元が引き締まり、清潔感が短時間で上がります。",
    effect:
      "左右差が目立ちにくくなり、目元がはっきりします。",
    howTo:
      "眉下の余分な毛を処理し、太さを残した自然な形を目指しましょう。",
  },
  {
    id: "sunscreen",
    priority: 3,
    category: "肌",
    title: "毎朝、日焼け止めを使う",
    reason:
      "紫外線対策は肌の清潔感を守るための基本です。",
    effect:
      "乾燥・赤み・くすみの予防につながります。",
    howTo:
      "外出前に顔全体へ薄く均一に塗り、汗をかいた日は塗り直しましょう。",
    href: "/products?category=sunscreen",
    hrefLabel:
      "UVケア商品を見る",
  },
  {
    id: "moisturize",
    priority: 4,
    category: "肌",
    title: "洗顔後に保湿する",
    reason:
      "肌の乾燥と過剰な皮脂を抑えるために、保湿は欠かせません。",
    effect:
      "テカリとカサつきが目立ちにくくなります。",
    howTo:
      "朝晩の洗顔後、化粧水またはオールインワンを顔全体になじませましょう。",
    href: "/products?category=skincare",
    hrefLabel:
      "スキンケア商品を見る",
  },
  {
    id: "hair-set",
    priority: 5,
    category: "髪型",
    title: "自分に合うヘアセットを覚える",
    reason:
      "美容室直後だけでなく、普段も理想の髪型を再現するためです。",
    effect:
      "毎日の印象が安定し、清潔感を維持できます。",
    howTo:
      "ドライヤーで根元を立ち上げ、少量のワックスで毛流れを整えましょう。",
    href: "/products?category=hairStyling",
    hrefLabel:
      "スタイリング商品を見る",
  },
  {
    id: "grooming",
    priority: 6,
    category: "身だしなみ",
    title: "ヒゲ・鼻毛・爪を整える",
    reason:
      "細部の手入れは、近距離で見たときの清潔感に直結します。",
    effect:
      "丁寧に手入れされた印象になります。",
    howTo:
      "外出前に鏡で確認し、気になったときにすぐ整えられる道具を用意しましょう。",
    href: "/products?category=other",
    hrefLabel:
      "身だしなみ商品を見る",
  },
];

type PlanCategory =
  | "髪型"
  | "眉毛"
  | "肌"
  | "身だしなみ";

function detectPriorityCategory(
  text: string,
): PlanCategory | null {
  const normalized =
    text.toLowerCase();

  if (
    normalized.includes("眉")
  ) {
    return "眉毛";
  }

  if (
    normalized.includes("髪") ||
    normalized.includes("ヘア") ||
    normalized.includes("前髪")
  ) {
    return "髪型";
  }

  if (
    normalized.includes("肌") ||
    normalized.includes("毛穴") ||
    normalized.includes("くすみ") ||
    normalized.includes("乾燥") ||
    normalized.includes("テカリ") ||
    normalized.includes("スキン")
  ) {
    return "肌";
  }

  if (
    normalized.includes("身だしなみ") ||
    normalized.includes("ヒゲ") ||
    normalized.includes("髭") ||
    normalized.includes("鼻毛") ||
    normalized.includes("爪")
  ) {
    return "身だしなみ";
  }

  return null;
}

function createPlanCategoryPriorities(
  analysis: AkanukeAnalysis | null,
) {
  const defaultOrder: PlanCategory[] =
    [
      "髪型",
      "眉毛",
      "肌",
      "身だしなみ",
    ];

  if (!analysis) {
    return new Map(
      defaultOrder.map(
        (category, index) => [
          category,
          index + 1,
        ],
      ),
    );
  }

  const detectedCategories: PlanCategory[] =
    [];

  for (
    const priority of analysis.priorities
  ) {
    const category =
      detectPriorityCategory(
        `${priority.title} ${priority.description}`,
      );

    if (
      category &&
      !detectedCategories.includes(
        category,
      )
    ) {
      detectedCategories.push(
        category,
      );
    }
  }

  for (
    const category of defaultOrder
  ) {
    if (
      !detectedCategories.includes(
        category,
      )
    ) {
      detectedCategories.push(
        category,
      );
    }
  }

  return new Map(
    detectedCategories.map(
      (category, index) => [
        category,
        index + 1,
      ],
    ),
  );
}

function Icon({
  name,
  className = "h-5 w-5",
}: {
  name: string;
  className?: string;
}) {
  const paths: Record<
    string,
    ReactNode
  > = {
    check: (
      <path d="m5 12 4 4L19 6" />
    ),
    chevron: (
      <path d="m9 18 6-6-6-6" />
    ),
    reset: (
      <>
        <path d="M20 7v5h-5" />
        <path d="M4 17v-5h5" />
        <path d="M6.1 9a7 7 0 0 1 11.5-2L20 9" />
        <path d="m4 15 2.4 2A7 7 0 0 0 17.9 15" />
      </>
    ),
    bag: (
      <>
        <path d="M6 8h12l1 12H5L6 8Z" />
        <path d="M9 8V6a3 3 0 0 1 6 0v2" />
      </>
    ),
    scissors: (
      <>
        <circle
          cx="6"
          cy="7"
          r="2.5"
        />
        <circle
          cx="6"
          cy="17"
          r="2.5"
        />
        <path d="m8.2 8.2 11.3 8.3" />
        <path d="m8.2 15.8 11.3-8.3" />
      </>
    ),
    brow: (
      <>
        <path d="M4 13c2.6-2.8 5.2-4 8-3.6 3 .4 5.7 1.7 8 4" />
        <path d="M6 16c4 1.2 8 1.2 12 0" />
      </>
    ),
    sparkle: (
      <>
        <path d="M12 3c.8 4.1 2.9 6.2 7 7-4.1.8-6.2 2.9-7 7-.8-4.1-2.9-6.2-7-7 4.1-.8 6.2-2.9 7-7Z" />
        <path d="M19 16c.3 1.7 1.3 2.7 3 3-1.7.3-2.7 1.3-3 3-.3-1.7-1.3-2.7-3-3 1.7-.3 2.7-1.3 3-3Z" />
      </>
    ),
  };

  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      className={className}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  );
}

function ProgressRing({
  progress,
}: {
  progress: number;
}) {
  const radius = 48;
  const circumference =
    2 * Math.PI * radius;

  const offset =
    circumference -
    (progress / 100) *
      circumference;

  return (
    <div className="relative h-[104px] w-[104px]">
      <svg
        viewBox="0 0 112 112"
        className="h-full w-full -rotate-90"
        aria-hidden="true"
      >
        <circle
          cx="56"
          cy="56"
          r={radius}
          fill="none"
          stroke="#FFFFFF"
          strokeWidth="7"
        />

        <circle
          cx="56"
          cy="56"
          r={radius}
          fill="none"
          stroke="#1677FF"
          strokeWidth="7"
          strokeLinecap="round"
          strokeDasharray={
            circumference
          }
          strokeDashoffset={offset}
          className="transition-[stroke-dashoffset] duration-700 ease-out"
        />
      </svg>

      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-[29px] font-black leading-none tracking-[-0.05em] text-[#1677FF]">
          {progress}%
        </span>

        <span className="mt-1 text-[8px] font-bold tracking-[0.12em] text-black/35">
          PROGRESS
        </span>
      </div>
    </div>
  );
}

function OrderPoint({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <li className="flex items-start gap-2 text-[11px] leading-5 text-black/55">
      <span className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full bg-[#1677FF]" />
      <span>{children}</span>
    </li>
  );
}

function SalonOrderGuide({
  isOpen,
  onToggle,
  afterImage,
  analysis,
}: {
  isOpen: boolean;
  onToggle: () => void;
  afterImage: string | null;
  analysis:
    | AkanukeAnalysis
    | null;
}) {
  const hairDirection =
    analysis?.afterDirection
      .hair ??
    "顔立ちと髪質に合う、清潔感のある髪型に整える";

  const hairAdvice =
    analysis?.hair.advice ??
    "前髪・サイド・トップのバランスを見ながら、扱いやすい形を相談する";

  return (
    <section className="mx-4 mt-7 overflow-hidden rounded-[24px] border border-[#1677FF]/15 bg-white shadow-[0_10px_34px_rgba(15,23,42,0.05)]">
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={isOpen}
        className="flex w-full items-center gap-3 bg-gradient-to-br from-[#EEF6FF] via-white to-white px-5 py-5 text-left transition hover:bg-[#F7F9FC]"
      >
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-white text-[#1677FF] shadow-[0_6px_22px_rgba(15,23,42,0.04)]">
          <Icon
            name="scissors"
            className="h-5 w-5"
          />
        </span>

        <span className="min-w-0 flex-1">
          <span className="block text-[9px] font-black tracking-[0.16em] text-[#1677FF]">
            SALON ORDER GUIDE
          </span>

          <span className="mt-1 block text-[17px] font-black tracking-[-0.035em] text-[#111111]">
            サロンで画面を見せるだけ
          </span>

          <span className="mt-1 block text-[10px] leading-5 text-black/55">
            髪型のオーダー内容を確認
          </span>
        </span>

        <span
          className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#EEF6FF] text-[#1677FF] transition-transform duration-300 ${
            isOpen
              ? "rotate-90"
              : ""
          }`}
        >
          <Icon
            name="chevron"
            className="h-4 w-4"
          />
        </span>
      </button>

      <div
        className={`grid transition-[grid-template-rows,opacity] duration-300 ${
          isOpen
            ? "grid-rows-[1fr] opacity-100"
            : "grid-rows-[0fr] opacity-0"
        }`}
      >
        <div className="overflow-hidden">
          <div className="border-t border-black/10 p-4">
            <div className="overflow-hidden rounded-[18px] border border-black/10 bg-[#F7F9FC]">
              <div className="relative bg-[#EEF6FF]">
                {afterImage ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={
                      afterImage
                    }
                    alt="AI診断で生成したあなたのAfterイメージ"
                    className="h-auto w-full object-contain"
                  />
                ) : (
                  <div className="flex aspect-[4/5] w-full items-center justify-center bg-[#EEF6FF] px-5 text-center">
                    <div>
                      <Icon
                        name="sparkle"
                        className="mx-auto h-7 w-7 text-[#1677FF]"
                      />

                      <p className="mt-3 text-[11px] font-black text-[#111111]">
                        After画像がありません
                      </p>

                      <p className="mt-1 text-[9px] leading-4 text-black/45">
                        診断結果画面でAfter画像を生成すると、
                        <br />
                        ここにサロン用の参考画像が表示されます。
                      </p>
                    </div>
                  </div>
                )}

                <span className="absolute left-3 top-3 rounded-full bg-[#FFD400] px-3 py-1.5 text-[9px] font-black text-[#111111]">
                  AFTER IMAGE
                </span>
              </div>

              <p className="px-4 py-3 text-center text-[9px] leading-4 text-black/35">
                ※AIが生成したAfterイメージをサロンでの相談用に表示しています。
              </p>
            </div>

            <div className="mt-4 rounded-[18px] border border-black/10 bg-white p-4">
              <div className="flex items-center gap-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#EEF6FF] text-[#1677FF]">
                  <Icon
                    name="scissors"
                    className="h-4 w-4"
                  />
                </span>

                <div>
                  <p className="text-[8px] font-black tracking-[0.14em] text-[#1677FF]">
                    HAIR STYLE
                  </p>

                  <h3 className="mt-0.5 text-[15px] font-black">
                    髪型のオーダー
                  </h3>
                </div>
              </div>

              <ul className="mt-4 space-y-2">
                <OrderPoint>
                  {hairDirection}
                </OrderPoint>

                <OrderPoint>
                  {hairAdvice}
                </OrderPoint>
              </ul>

              <div className="mt-4 rounded-[14px] bg-[#EEF6FF] p-4">
                <p className="text-[10px] font-black text-[#1677FF]">
                  美容師さんへの伝え方
                </p>

                <p className="mt-2 text-[11px] font-bold leading-6 text-[#111111]">
                  「
                  {
                    hairDirection
                  }
                  」という方向で、
                  自分の顔立ちと髪質に合わせて調整してください。
                  セット方法も教えてください。
                </p>
              </div>
            </div>

            <div className="mt-4 flex items-start gap-3 rounded-[14px] bg-[#F7F9FC] px-4 py-4">
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white text-[#1677FF]">
                <Icon
                  name="sparkle"
                  className="h-4 w-4"
                />
              </span>

              <p className="text-[10px] leading-5 text-black/55">
                この画面を美容室のスタッフに見せて、
                顔立ちや髪質に合わせて最終調整してもらうのがおすすめです。
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default function PlanPage() {
    const planViewTrackedRef =
    useRef(false);

    const [
    backHref,
    setBackHref,
  ] = useState("/result");

  const [
    backLabel,
    setBackLabel,
  ] = useState(
    "診断結果へ戻る",
  );

  useEffect(() => {
    const searchParams =
      new URLSearchParams(
        window.location.search,
      );

    if (
      searchParams.get("from") ===
      "dashboard"
    ) {
      setBackHref(
        "/dashboard",
      );

      setBackLabel(
        "マイページへ戻る",
      );
    }
  }, []);

  const [
    completedIds,
    setCompletedIds,
  ] = useState<string[]>([]);

  const [
    isSalonGuideOpen,
    setIsSalonGuideOpen,
  ] = useState(false);

  const [
    openedId,
    setOpenedId,
  ] = useState<
    string | null
  >(null);

  const [
    salonAfterImage,
    setSalonAfterImage,
  ] = useState<
    string | null
  >(null);

  const [
    salonAnalysis,
    setSalonAnalysis,
  ] =
    useState<AkanukeAnalysis | null>(
      null,
    );

  const [
    loaded,
    setLoaded,
  ] = useState(false);

  const [
    showStickyStatus,
    setShowStickyStatus,
  ] = useState(false);

  const statusCardRef =
    useRef<HTMLElement | null>(
      null,
    );

  /*
   * 元のCURRENT STATUSカードが
   * ヘッダーより上へ完全に消えたら、
   * コンパクトなステータスバーを表示します。
   */
  useEffect(() => {
    const handleScroll = () => {
      const target =
        statusCardRef.current;

      if (!target) {
        return;
      }

      const rect =
        target.getBoundingClientRect();

      setShowStickyStatus(
  rect.bottom <= 52,
);
    };

    handleScroll();

    window.addEventListener(
      "scroll",
      handleScroll,
      {
        passive: true,
      },
    );

    window.addEventListener(
      "resize",
      handleScroll,
    );

    return () => {
      window.removeEventListener(
        "scroll",
        handleScroll,
      );

      window.removeEventListener(
        "resize",
        handleScroll,
      );
    };
  }, []);

/*
 * Supabaseに保存されている最新診断を正として、
 * After画像と診断内容を復元します。
 *
 * SafariとLINE内ブラウザではブラウザストレージを共有できず、
 * ローカルデータが古い可能性もあるため、
 * Plan画面では常にSupabaseの最新診断を利用します。
 */
useEffect(() => {
  let isCancelled = false;

  async function restoreLatestDiagnosis() {
    try {
      const latestResponse =
        await fetch(
          "/api/diagnoses/latest",
          {
            method: "GET",
            cache: "no-store",
          },
        );

      const latestData =
        (await latestResponse.json()) as {
          diagnosisId?: string | null;
          error?: string;
        };

      if (!latestResponse.ok) {
        throw new Error(
          latestData.error ??
            "最新の診断情報を取得できませんでした。",
        );
      }

      const latestDiagnosisId =
        typeof latestData.diagnosisId ===
          "string" &&
        latestData.diagnosisId.trim().length > 0
          ? latestData.diagnosisId
          : null;

      if (
        !latestDiagnosisId ||
        isCancelled
      ) {
        if (!isCancelled) {
          setSalonAfterImage(null);
          setSalonAnalysis(null);
        }

        return;
      }

      window.sessionStorage.setItem(
        DIAGNOSIS_ID_STORAGE_KEY,
        latestDiagnosisId,
      );

      const diagnosisResponse =
        await fetch(
          `/api/diagnoses/${encodeURIComponent(
            latestDiagnosisId,
          )}`,
          {
            method: "GET",
            cache: "no-store",
          },
        );

      const diagnosisData =
        (await diagnosisResponse.json()) as {
          diagnosis?: {
            analysis?: AkanukeAnalysis;
            afterImageUrl?: string | null;
          };
          error?: string;
        };

      if (!diagnosisResponse.ok) {
        throw new Error(
          diagnosisData.error ??
            "診断結果を取得できませんでした。",
        );
      }

      if (
        isCancelled ||
        !diagnosisData.diagnosis
      ) {
        return;
      }

      const savedAnalysis =
        diagnosisData.diagnosis.analysis;

      if (savedAnalysis) {
        setSalonAnalysis(
          savedAnalysis,
        );
      } else {
        setSalonAnalysis(null);
      }

      setSalonAfterImage(
        diagnosisData.diagnosis
          .afterImageUrl ?? null,
      );
    } catch (error) {
      console.error(
        "[AKANUKE.AI] Plan画面で最新診断を読み込めませんでした:",
        error,
      );

      /*
       * 最新データを確認できなかった場合、
       * 古い診断データを誤表示しないようにします。
       */
      if (!isCancelled) {
        setSalonAfterImage(null);
        setSalonAnalysis(null);
      }
    }
  }

  void restoreLatestDiagnosis();

  return () => {
    isCancelled = true;
  };
}, []);

  /*
   * 現在の診断IDごとに、
   * 垢抜けプランのチェック状態を復元します。
   *
   * SafariとLINE内ブラウザではsessionStorageが共有されないため、
   * 診断IDが保存されていない場合は最新診断IDをAPIから取得します。
   */
  useEffect(() => {
    let isActive = true;

    async function getLatestDiagnosisId() {
      const response = await fetch(
        "/api/diagnoses/latest",
        {
          method: "GET",
          cache: "no-store",
        },
      );

      const data =
        (await response.json()) as {
          diagnosisId?: string | null;
          error?: string;
        };

      if (!response.ok) {
        throw new Error(
          data.error ??
            "最新の診断情報を取得できませんでした。",
        );
      }

      const latestDiagnosisId =
        typeof data.diagnosisId ===
          "string" &&
        data.diagnosisId.trim().length > 0
          ? data.diagnosisId
          : null;

      if (latestDiagnosisId) {
        window.sessionStorage.setItem(
          DIAGNOSIS_ID_STORAGE_KEY,
          latestDiagnosisId,
        );
      }

      return latestDiagnosisId;
    }

    async function fetchPlanProgress(
      diagnosisId: string,
    ) {
      const response = await fetch(
        `/api/plan-progress?diagnosisId=${encodeURIComponent(
          diagnosisId,
        )}`,
        {
          method: "GET",
          cache: "no-store",
        },
      );

      const data =
        (await response.json()) as {
          completedTaskIds?: string[];
          error?: string;
        };

      return {
        response,
        data,
      };
    }

    async function loadPlanProgress() {
      try {
        const diagnosisId =
  await getLatestDiagnosisId();

if (!diagnosisId) {
  if (isActive) {
    setCompletedIds([]);
  }

  return;
}

const { response, data } =
  await fetchPlanProgress(
    diagnosisId,
  );

        if (!response.ok) {
          throw new Error(
            data.error ??
              "プランの進捗を取得できませんでした。",
          );
        }

        if (!isActive) {
          return;
        }

        const validCompletedIds =
          Array.isArray(
            data.completedTaskIds,
          )
            ? data.completedTaskIds.filter(
                (id): id is string =>
                  typeof id ===
                    "string" &&
                  planTasks.some(
                    (task) =>
                      task.id === id,
                  ),
              )
            : [];

        setCompletedIds(
          validCompletedIds,
        );
      } catch (error) {
        console.error(
          "[AKANUKE.AI] プラン進捗取得エラー:",
          error,
        );

        if (isActive) {
          setCompletedIds([]);
        }
      } finally {
        if (isActive) {
          setLoaded(true);
        }
      }
    }

    void loadPlanProgress();

    return () => {
      isActive = false;
    };
  }, []);

  const categoryPriorities =
  useMemo(
    () =>
      createPlanCategoryPriorities(
        salonAnalysis,
      ),
    [salonAnalysis],
  );

const orderedPlanTasks =
  useMemo(
    () =>
      [...planTasks].sort(
        (a, b) => {
          const aPriority =
            categoryPriorities.get(
              a.category as PlanCategory,
            ) ?? 999;

          const bPriority =
            categoryPriorities.get(
              b.category as PlanCategory,
            ) ?? 999;

          if (
            aPriority !==
            bPriority
          ) {
            return (
              aPriority -
              bPriority
            );
          }

          /*
           * 同じカテゴリ内では、
           * 今までのタスク順を維持します。
           */
          return (
            a.priority -
            b.priority
          );
        },
      ),
    [categoryPriorities],
  );

  const completedCount =
    completedIds.length;

  const progress = useMemo(
    () =>
      Math.round(
        (completedCount /
          planTasks.length) *
          100,
      ),
    [completedCount],
  );

  useEffect(() => {
    if (
      !loaded ||
      planViewTrackedRef.current
    ) {
      return;
    }

    planViewTrackedRef.current =
      true;

    const searchParams =
      new URLSearchParams(
        window.location.search,
      );

    const entrySource =
      searchParams.get("from") ===
      "dashboard"
        ? "dashboard"
        : "result";

    trackEvent(
      "plan_view",
      {
        completed_task_count:
          completedCount,

        progress_percent:
          progress,

        entry_source:
          entrySource,
      },
    );
  }, [
    loaded,
    completedCount,
    progress,
  ]);


async function resolveDiagnosisId() {
  const response = await fetch(
    "/api/diagnoses/latest",
    {
      method: "GET",
      cache: "no-store",
    },
  );

  const data =
    (await response.json()) as {
      diagnosisId?: string | null;
      error?: string;
    };

  if (!response.ok) {
    throw new Error(
      data.error ??
        "最新の診断情報を取得できませんでした。",
    );
  }

  const latestDiagnosisId =
    typeof data.diagnosisId ===
      "string" &&
    data.diagnosisId.trim().length > 0
      ? data.diagnosisId
      : null;

  if (!latestDiagnosisId) {
    throw new Error(
      "診断IDを確認できませんでした。",
    );
  }

  window.sessionStorage.setItem(
    DIAGNOSIS_ID_STORAGE_KEY,
    latestDiagnosisId,
  );

  return latestDiagnosisId;
}

  async function savePlanProgress(
    nextCompletedIds: string[],
  ) {
    const diagnosisId =
      await resolveDiagnosisId();

    const response = await fetch(
      "/api/plan-progress",
      {
        method: "PUT",

        headers: {
          "Content-Type":
            "application/json",
        },

        body: JSON.stringify({
          diagnosisId,
          completedTaskIds:
            nextCompletedIds,
        }),
      },
    );

    const data =
      (await response.json()) as {
        completedTaskIds?: string[];
        error?: string;
      };

    if (!response.ok) {
      throw new Error(
        data.error ??
          "プランの進捗を保存できませんでした。",
      );
    }
  }

  const toggleCompleted = (
    id: string,
  ) => {
    const previousCompletedIds =
      completedIds;

    const nextCompletedIds =
      completedIds.includes(id)
        ? completedIds.filter(
            (item) =>
              item !== id,
          )
        : [
            ...completedIds,
            id,
          ];

    /*
     * 画面上はすぐにチェック状態を変更し、
     * 裏側でSupabaseへ保存します。
     */
    setCompletedIds(
      nextCompletedIds,
    );

    void savePlanProgress(
      nextCompletedIds,
    ).catch((error) => {
      console.error(
        "[AKANUKE.AI] プラン進捗保存エラー:",
        error,
      );

      /*
       * 保存に失敗した場合は、
       * チェック状態を元に戻します。
       */
      setCompletedIds(
        previousCompletedIds,
      );
    });
  };

const resetCompleted = () => {
  const previousCompletedIds =
    completedIds;

  setCompletedIds([]);

  void savePlanProgress(
    [],
  ).catch((error) => {
    console.error(
      "[AKANUKE.AI] プラン進捗リセットエラー:",
      error,
    );

    setCompletedIds(
      previousCompletedIds,
    );
  });
};

if (!loaded) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-white">
        <div className="h-9 w-9 animate-spin rounded-full border-[3px] border-black/10 border-t-[#1677FF]" />
      </main>
    );
  }

  return (
    <AppShell background="white">
      <div className="overflow-x-clip bg-white">
        <AppHeader
  backHref={backHref}
  backLabel={backLabel}
/>
        {showStickyStatus && (
  <div className="fixed left-1/2 top-[68px] z-30 w-full max-w-[480px] -translate-x-1/2 border-b border-[#1677FF]/10 bg-white/95 px-4 py-2.5 shadow-[0_6px_18px_rgba(15,23,42,0.05)] backdrop-blur-xl">
            <div className="flex items-center gap-3">
              <div className="min-w-0 flex-1">
                <p className="text-[8px] font-black tracking-[0.14em] text-[#1677FF]">
                  CURRENT STATUS
                </p>

                <div className="mt-0.5 flex items-end gap-1.5">
                  <p className="text-[15px] font-black tracking-[-0.03em] text-[#111111]">
                    <span className="text-[#1677FF]">
                      {
                        completedCount
                      }{" "}
                      /{" "}
                      {
                        planTasks.length
                      }
                    </span>{" "}
                    完了
                  </p>

                  <span className="pb-[1px] text-[9px] font-bold text-black/35">
                    {progress}%
                  </span>
                </div>
              </div>

              <div className="w-[110px] shrink-0">
                <div className="h-2 overflow-hidden rounded-full bg-[#EEF6FF]">
                  <div
                    className="h-full rounded-full bg-[#1677FF] transition-[width] duration-500"
                    style={{
                      width:
                        `${progress}%`,
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="pb-32">
          <section className="px-5 pb-4 pt-3 text-center sm:pb-6 sm:pt-7">
  <p className="text-[9px] font-black tracking-[0.18em] text-[#1677FF] sm:text-[10px]">
    PERSONAL AKANUKE PLAN
  </p>

  <h1 className="mt-1.5 text-[23px] font-black leading-[1.2] tracking-[-0.045em] sm:mt-2 sm:text-[29px]">
    あなた専用の垢抜けプラン
  </h1>

  <p className="mx-auto mt-1.5 max-w-[340px] text-[11px] leading-[1.7] text-black/55 sm:mt-2 sm:text-[12px] sm:leading-5">
    優先順位の高い項目から、自分のペースで進めてください。
  </p>
</section>

          <section
            ref={statusCardRef}
            className="mx-4 rounded-[24px] border border-[#1677FF]/10 bg-[#EEF6FF] px-5 py-3.5 shadow-[0_10px_34px_rgba(15,23,42,0.05)]"
          >
            <div className="flex items-center gap-5">
              <ProgressRing
                progress={
                  progress
                }
              />

              <div className="min-w-0 flex-1">
                <p className="text-[9px] font-black tracking-[0.13em] text-[#1677FF]">
                  CURRENT STATUS
                </p>

                <h2 className="mt-2 text-[22px] font-black tracking-[-0.04em] text-[#111111]">
                  <span className="text-[#1677FF]">
                    {
                      completedCount
                    }{" "}
                    /{" "}
                    {
                      planTasks.length
                    }
                  </span>{" "}
                  完了
                </h2>
              </div>
            </div>
          </section>

          <SalonOrderGuide
            isOpen={
              isSalonGuideOpen
            }
            onToggle={() =>
              setIsSalonGuideOpen(
                (current) =>
                  !current,
              )
            }
            afterImage={
              salonAfterImage
            }
            analysis={
              salonAnalysis
            }
          />

          <section className="mx-4 mt-7">
            <div className="flex items-end justify-between">
              <div>
                <p className="text-[10px] font-black tracking-[0.16em] text-[#1677FF]">
                  ACTION LIST
                </p>

                <h2 className="mt-1 text-[21px] font-black tracking-[-0.035em]">
                  やることリスト
                </h2>
              </div>
            </div>

            <div className="mt-4 space-y-3">
              {orderedPlanTasks.map(
  (task, index) => {
                  const completed =
                    completedIds.includes(
                      task.id,
                    );

                  const opened =
                    openedId ===
                    task.id;

                  return (
                    <article
                      key={
                        task.id
                      }
                      className={`overflow-hidden rounded-[18px] border bg-white ${
                        completed
                          ? "border-[#FFD400]/40"
                          : "border-black/10"
                      }`}
                    >
                      <div className="flex items-start gap-3 p-4">
                        <button
                          type="button"
                          onClick={() =>
                            toggleCompleted(
                              task.id,
                            )
                          }
                          aria-label={`${task.title}を${
                            completed
                              ? "未完了"
                              : "完了"
                          }にする`}
                          className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full border transition ${
                            completed
                              ? "border-[#1677FF] bg-[#1677FF] text-white"
                              : "border-black/10 bg-[#EEF6FF] text-transparent"
                          }`}
                        >
                          <Icon
                            name="check"
                            className="h-4 w-4"
                          />
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            setOpenedId(
                              opened
                                ? null
                                : task.id,
                            )
                          }
                          className="min-w-0 flex-1 text-left"
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div>
                              <p className="text-[9px] font-black text-[#1677FF]">
  優先度{" "}
  {index + 1}
  ・
  {task.category}
</p>

                              <h3
                                className={`mt-1 text-[15px] font-black ${
                                  completed
                                    ? "text-black/35 line-through"
                                    : "text-[#111111]"
                                }`}
                              >
                                {
                                  task.title
                                }
                              </h3>
                            </div>

                            <span
                              className={`mt-1 transition ${
                                opened
                                  ? "rotate-90"
                                  : ""
                              }`}
                            >
                              <Icon name="chevron" />
                            </span>
                          </div>
                        </button>
                      </div>

                      {opened && (
                        <div className="border-t border-black/10 bg-white px-4 py-4">
                          <div className="space-y-3 text-[11px] leading-5">
                            <div>
                              <p className="font-black">
                                なぜ必要？
                              </p>

                              <p className="mt-1 text-black/55">
                                {
                                  task.reason
                                }
                              </p>
                            </div>

                            <div>
                              <p className="font-black">
                                期待できる変化
                              </p>

                              <p className="mt-1 text-black/55">
                                {
                                  task.effect
                                }
                              </p>
                            </div>

                            <div>
                              <p className="font-black">
                                具体的なやり方
                              </p>

                              <p className="mt-1 text-black/55">
                                {
                                  task.howTo
                                }
                              </p>
                            </div>
                          </div>

                          {task.href && (
                            <Link
                              href={
                                task.href
                              }
                              className="mt-4 flex min-h-11 items-center justify-between rounded-[12px] bg-[#EEF6FF] px-4 text-[11px] font-black text-[#1677FF]"
                            >
                              {
                                task.hrefLabel
                              }

                              <Icon name="chevron" />
                            </Link>
                          )}
                        </div>
                      )}
                    </article>
                  );
                },
              )}
            </div>
          </section>

          <section className="mx-4 mt-7 overflow-hidden rounded-[24px] border border-[#1677FF]/10 bg-gradient-to-br from-white via-white to-[#EEF6FF] shadow-[0_14px_40px_rgba(22,119,255,0.08)]">
            <div className="relative px-5 pb-5 pt-6">
              <div className="absolute right-5 top-5 flex h-16 w-16 items-center justify-center rounded-full bg-[#EEF6FF] text-[#1677FF]">
                <Icon
                  name="bag"
                  className="h-8 w-8"
                />
              </div>

              <p className="pr-20 text-[9px] font-black tracking-[0.16em] text-[#1677FF]">
                RECOMMENDED FOR YOU
              </p>

              <h2 className="mt-3 whitespace-nowrap pr-20 text-[18px] font-black leading-[1.45] tracking-[-0.04em] min-[390px]:text-[20px]">
                あなたに合うおすすめ商品
              </h2>

              <p className="mt-3 max-w-[340px] text-left text-[11px] leading-5 text-black/55">
                あなたに必要なケア・スタイリング商品を厳選しています。
              </p>

              <Link
                href="/products"
                className="mt-6 flex min-h-[56px] items-center justify-center gap-3 rounded-[15px] bg-[#FFD400] px-5 text-[14px] font-black text-[#111111] shadow-[0_10px_34px_rgba(15,23,42,0.05)] transition hover:-translate-y-0.5 active:scale-[0.99]"
              >
                おすすめ商品を見る

                <span
                  aria-hidden="true"
                  className="text-[18px]"
                >
                  →
                </span>
              </Link>
            </div>
          </section>

          {progress === 100 && (
            <section className="mx-4 mt-6 rounded-[20px] border border-[#FFD400]/40 bg-[#FFF9D9] p-5 text-center">
              <p className="text-[10px] font-black tracking-[0.14em] text-[#1677FF]">
                PLAN COMPLETE
              </p>

              <h2 className="mt-2 text-[21px] font-black">
                すべてのタスクが完了しました
              </h2>

              <p className="mt-2 text-[11px] leading-5 text-black/55">
                同じ条件で写真を撮り直し、Before / Afterを確認しましょう。
              </p>

              <Link
                href="/upload"
                className="mt-4 flex min-h-12 items-center justify-center rounded-[12px] bg-[#FFD400] text-[12px] font-black text-[#111111]"
              >
                もう一度診断する
              </Link>
            </section>
          )}

          <Link
  href="/dashboard"
  className="mx-4 mt-6 flex min-h-[54px] items-center justify-center gap-2 rounded-[14px] bg-[#1677FF] px-5 text-[12px] font-black text-white shadow-[0_8px_24px_rgba(22,119,255,0.18)] transition hover:-translate-y-0.5 hover:bg-[#0F6FEF] active:scale-[0.99]"
>
  マイページへ

  <span
    aria-hidden="true"
    className="text-[16px] font-black"
  >
    →
  </span>
</Link>

<button
  type="button"
  onClick={resetCompleted}
  
  className="mx-auto mt-5 flex items-center gap-2 text-[10px] font-black text-black/35 transition hover:text-black/55"
>
  <Icon
    name="reset"
    className="h-4 w-4"
  />

  チェック状況をリセット
</button>
        </div>
      </div>
    </AppShell>
  );
}