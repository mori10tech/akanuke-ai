"use client";

import Image from "next/image";
import Link from "next/link";

import {
  useEffect,
  useState,
} from "react";

import AppHeader from "../components/AppHeader";
import { trackEvent } from "../../lib/analytics";

type BrowserEnvironment = {
  isIos: boolean;
  isAndroid: boolean;
  isLineBrowser: boolean;
  isRecommendedExternalBrowser: boolean;
  isLikelyInAppBrowser: boolean;
  recommendedBrowserName: string;
};

function detectBrowserEnvironment(): BrowserEnvironment {
  const userAgent =
    window.navigator.userAgent;

  const isIos =
    /iPhone|iPad|iPod/i.test(
      userAgent,
    );

  const isAndroid =
    /Android/i.test(
      userAgent,
    );

  const isLineBrowser =
    /Line\//i.test(
      userAgent,
    );

  const isIosSafari =
    isIos &&
    /Safari/i.test(
      userAgent,
    ) &&
    !/CriOS|FxiOS|EdgiOS|OPiOS/i.test(
      userAgent,
    );

  const isAndroidChrome =
    isAndroid &&
    /Chrome\//i.test(
      userAgent,
    ) &&
    !/SamsungBrowser|EdgA|OPR\//i.test(
      userAgent,
    );

  const knownInAppBrowser =
    /Instagram|FBAN|FBAV|Twitter|X\//i.test(
      userAgent,
    );

  const isRecommendedExternalBrowser =
    isIosSafari ||
    isAndroidChrome;

  const isLikelyInAppBrowser =
    !isLineBrowser &&
    (
      knownInAppBrowser ||
      (
        (isIos ||
          isAndroid) &&
        !isRecommendedExternalBrowser
      )
    );

  return {
    isIos,
    isAndroid,
    isLineBrowser,
    isRecommendedExternalBrowser,
    isLikelyInAppBrowser,
    recommendedBrowserName:
      isIos
        ? "Safari"
        : isAndroid
          ? "Chrome"
          : "Safari / Chrome",
  };
}

function getBrowserType(
  environment:
    | BrowserEnvironment
    | null,
) {
  if (!environment) {
    return "unknown";
  }

  if (
    environment.isLineBrowser
  ) {
    return "line";
  }

  if (
    environment.isLikelyInAppBrowser
  ) {
    return "in_app";
  }

  if (
    environment.isIos
  ) {
    return "ios_browser";
  }

  if (
    environment.isAndroid
  ) {
    return "android_browser";
  }

  return "desktop_browser";
}

function getSafeNext(
  value: string | null,
) {
  if (
    value?.startsWith("/") &&
    !value.startsWith("//")
  ) {
    return value;
  }

  return "/dashboard";
}

export default function LoginPage() {
  const [
    lineLoginUrl,
    setLineLoginUrl,
  ] =
    useState<string | null>(
      null,
    );

  const [
    isLineLoading,
    setIsLineLoading,
  ] =
    useState(true);

  const [
    errorMessage,
    setErrorMessage,
  ] =
    useState("");

  const [
    copyMessage,
    setCopyMessage,
  ] =
    useState("");

  const [
    browserEnvironment,
    setBrowserEnvironment,
  ] =
    useState<BrowserEnvironment | null>(
      null,
    );

  useEffect(() => {
    let cancelled =
      false;

    async function prepareLineLogin() {
      try {
        const environment =
          detectBrowserEnvironment();

        if (!cancelled) {
          setBrowserEnvironment(
            environment,
          );
        }

        const searchParams =
          new URLSearchParams(
            window.location.search,
          );

        const reason =
          searchParams.get(
            "reason",
          );

        const safeNext =
          getSafeNext(
            searchParams.get(
              "next",
            ),
          );

        if (
          reason ===
          "line_friend_required"
        ) {
          setErrorMessage(
            "AKANUKE.AIのご利用には、LINE公式アカウントの友だち追加が必要です。友だち追加後、もう一度LINEでログインしてください。",
          );
        } else if (
          reason ===
          "line_friend_check_failed"
        ) {
          setErrorMessage(
            "LINEの友だち追加状況を確認できませんでした。時間をおいて、もう一度LINEでログインしてください。",
          );
        
        } else if (
          reason ===
          "auth_failed"
        ) {
          setErrorMessage(
  "ご利用環境により、ログインが完了しませんでした。\n下のログインボタンから、もう一度お試しください。",
);
        }

const liffId =
  process.env.NEXT_PUBLIC_LINE_LIFF_ID;

if (!liffId) {
  throw new Error(
    "NEXT_PUBLIC_LINE_LIFF_ID が設定されていません。",
  );
}

const nextLiffUrl =
  `https://liff.line.me/${liffId}?next=${encodeURIComponent(
    safeNext,
  )}`;

if (!cancelled) {
  setLineLoginUrl(
    nextLiffUrl,
  );

  setIsLineLoading(
    false,
  );
}

      } catch (error) {
        console.error(
          "LINE login preparation error:",
          error,
        );

        if (!cancelled) {
          setErrorMessage(
            "LINE ログインを開始できませんでした。時間をおいてもう一度お試しください。",
          );

          setIsLineLoading(
            false,
          );
        }
      }
    }

    void prepareLineLogin();

    return () => {
      cancelled = true;
    };
  }, []);

  async function copyCurrentUrl() {
    try {
      await navigator.clipboard.writeText(
        window.location.href,
      );

      setCopyMessage(
        "URLをコピーしました",
      );

      window.setTimeout(
        () => {
          setCopyMessage(
            "",
          );
        },
        2500,
      );
    } catch (error) {
      console.error(
        "Copy login URL error:",
        error,
      );

      setCopyMessage(
        "URLをコピーできませんでした",
      );
    }
  }

  function handleLineLoginStart() {
    const searchParams =
      new URLSearchParams(
        window.location.search,
      );

    const safeNext =
      getSafeNext(
        searchParams.get(
          "next",
        ),
      );

    trackEvent(
      "line_login_start",
      {
        browser_type:
          getBrowserType(
            browserEnvironment,
          ),

        reason:
          searchParams.get(
            "reason",
          ) ??
          "normal",

        next_path:
          safeNext,
      },
    );
  }

  const showExternalBrowserWarning =
    browserEnvironment
      ?.isLikelyInAppBrowser ===
    true;

  const recommendedBrowserName =
    browserEnvironment
      ?.recommendedBrowserName ??
    "Safari / Chrome";

  return (
    <main className="min-h-screen bg-white text-[#111111]">
      <div className="mx-auto min-h-screen w-full max-w-[480px] border-x border-black/5 bg-white">
        <AppHeader
          backHref="/"
          backLabel="トップページへ戻る"
          backMode="history"
        />

        <div className="px-5 pb-12 pt-6 sm:pt-10">
          <div className="text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center overflow-hidden rounded-[16px] bg-white shadow-[0_8px_28px_rgba(15,23,42,0.08)] sm:h-20 sm:w-20 sm:rounded-[20px]">
              <Image
                src="/icon-512.png"
                alt="AKANUKE.AI"
                width={80}
                height={80}
                priority
                className="h-full w-full object-cover"
              />
            </div>

            <p className="mt-4 text-[9px] font-black tracking-[0.16em] text-[#1677FF] sm:mt-6 sm:text-[11px]">
              WELCOME TO AKANUKE.AI
            </p>

            <h1 className="mt-1.5 text-[23px] font-black leading-[1.2] tracking-[-0.04em] sm:mt-3 sm:text-[28px]">
              LINE ログイン
            </h1>

          </div>

          {showExternalBrowserWarning && (
            <div className="mt-7 rounded-[18px] border border-[#FFD400]/50 bg-[#FFF9D9] p-4">
              <p className="text-[12px] font-black text-[#111111]">
                {recommendedBrowserName}
                でのログインがおすすめです
              </p>

              <p className="mt-2 text-[11px] leading-5 text-black/60">
                アプリ内ブラウザではLINEアプリが自動で開かない場合があります。このページを
                {
                  recommendedBrowserName
                }
                で開いてからログインしてください。
              </p>

              <button
                type="button"
                onClick={() =>
                  void copyCurrentUrl()
                }
                className="mt-3 flex min-h-[42px] w-full items-center justify-center rounded-[11px] border border-black/10 bg-white px-4 text-[11px] font-black text-[#111111]"
              >
                このページのURLをコピー
              </button>

              {copyMessage && (
                <p className="mt-2 text-center text-[10px] font-bold text-black/45">
                  {
                    copyMessage
                  }
                </p>
              )}
            </div>
          )}

          <div className="mt-5 rounded-[22px] border border-black/10 bg-white p-5 shadow-[0_10px_34px_rgba(15,23,42,0.05)] sm:mt-8">
            <div className="rounded-[16px] bg-[#F7F9FC] px-4 py-4">
              <p className="text-[13px] font-black text-[#111111]">
                LINE ログインでできること
              </p>

              <ul className="mt-3 space-y-2 text-[11px] font-bold leading-5 text-black/70">
                <li>
                  ・診断結果をいつでも確認
                </li>

                <li>
                  ・あなた専用の垢抜けプランを保存
                </li>

                <li>
                  ・おすすめ商品をすぐに確認
                </li>
              </ul>
            </div>

            {errorMessage && (
              <div
                role="alert"
                className="mt-5 rounded-[12px] border border-red-200 bg-red-50 px-4 py-3"
              >
                <p className="whitespace-pre-line text-[11px] font-bold leading-5 text-red-600">
                  {
                    errorMessage
                  }
                </p>
              </div>
            )}

{lineLoginUrl ? (
  <a
    href={
      lineLoginUrl
    }
    onClick={
      handleLineLoginStart
    }
    className="mt-5 flex min-h-[56px] w-full items-center justify-center gap-3 rounded-[12px] bg-[#06C755] px-5 text-[14px] font-black text-white shadow-[0_10px_34px_rgba(15,23,42,0.08)] transition hover:-translate-y-0.5 active:scale-[0.99]"
  >
    <span
      aria-hidden="true"
      className="flex h-7 min-w-7 items-center justify-center rounded-full bg-white px-1 text-[8px] font-black text-[#06C755]"
    >
      LINE
    </span>

    LINE ログイン
  </a>
) : (
  <button
    type="button"
    disabled
    className="mt-5 flex min-h-[56px] w-full items-center justify-center gap-3 rounded-[12px] bg-[#06C755] px-5 text-[14px] font-black text-white opacity-50 shadow-[0_10px_34px_rgba(15,23,42,0.08)]"
  >
    <span
      aria-hidden="true"
      className="flex h-7 min-w-7 items-center justify-center rounded-full bg-white px-1 text-[8px] font-black text-[#06C755]"
    >
      LINE
    </span>

    {isLineLoading
      ? "LINEログインを準備中..."
      : "LINE ログイン"}
  </button>
)}

            <div className="mt-4" />

            <div className="mt-3 rounded-[16px] border border-[#1677FF]/10 bg-[#EEF6FF] p-4">
              <p className="text-[14px] font-black text-[#111111]">
  LINE ログインでお困りの方へ
</p>

<div className="mt-4 space-y-5 text-[12px] font-semibold leading-5 text-black">
  <div>
  <p className="font-black text-[#111111]">
    ・メールアドレス/パスワードの入力を求められた
  </p>

  <p className="mt-2 font-semibold text-black/75">
    画面下部の
    <span className="font-black text-[#111111]">
      ［LINEアプリでログイン］
    </span>
    をタップしてください
  </p>
</div>

  <div>
    <p className="font-black text-[#111111]">
    ・ログインが完了しませんでした と表示された
    </p>
    <p className="mt-2 font-semibold text-black/75">
  <span className="text-[12px] font-black text-[#111111]">
    ［LINE ログイン］
  </span>
  をもう一度タップしてください
</p>
  </div>

  <div>
    <p className="font-black text-[#111111]">
      ・アプリ内ブラウザでログインできない
    </p>
    <p className="mt-2 font-semibold text-black/75">
      SafariまたはChromeで開き直してください
    </p>
  </div>
</div>

              <button
                type="button"
                onClick={() =>
                  void copyCurrentUrl()
                }
                className="mt-4 flex min-h-[42px] w-full items-center justify-center rounded-[11px] bg-white px-4 text-[11px] font-black text-[#1677FF] shadow-[0_4px_14px_rgba(15,23,42,0.04)]"
              >
                このページのURLをコピー
              </button>

              {copyMessage && (
                <p className="mt-2 text-center text-[10px] font-bold text-black/45">
                  {
                    copyMessage
                  }
                </p>
              )}

              <a
                href="https://help.line.me/line/ios/sp?lang=ja&contentId=20020693"
                target="_blank"
                rel="noreferrer"
                className="mt-3 flex min-h-[40px] items-center justify-center text-[10px] font-bold text-black/45 underline underline-offset-2"
              >
                LINE公式ヘルプを確認
              </a>
            </div>

            <p className="mt-4 text-center text-[10px] leading-5 text-black/40">
              続行すると、
              <Link
                href="/terms"
                className="font-bold text-[#1677FF]"
              >
                利用規約
              </Link>
              と
              <a
                href="/privacy"
                target="_blank"
                rel="noreferrer"
                className="font-bold text-[#1677FF]"
              >
                プライバシーポリシー
              </a>
              に同意したものとみなされます。
            </p>
          </div>
        </div>
      </div>
    </main>
  );
}